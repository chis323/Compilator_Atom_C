void main()
{
	double	r,pi;
	pi=3.14;
	put_s("r=");
	r=get_d();
	put_s("perimetrul=");
	put_d(2e0*pi*r);
	put_s("aria=");
	put_d(pi*r*r);
}
