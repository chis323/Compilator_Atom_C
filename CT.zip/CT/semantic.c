#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include "lexical_analyzer.h"

#define MAX_SYMBOLS 1024
#define MAX_NAME 64

typedef enum { CLS_VAR, CLS_FUNC, CLS_STRUCT } ClassKind;
typedef enum { TB_INT, TB_DOUBLE, TB_CHAR, TB_STRUCT, TB_VOID } TypeBase;
typedef enum { MEM_GLOBAL, MEM_ARG, MEM_LOCAL } MemType;

typedef struct Type Type;
typedef struct Symbol Symbol;

typedef struct Type {
    TypeBase typeBase;
    Symbol* s;
    int nElements;
} Type;

struct Symbol {
    char name[MAX_NAME];
    ClassKind cls;
    Type type;
    MemType mem;
    int depth;
    Symbol* next;
    Symbol* args;
    Symbol* members;
};

Symbol* symbols = NULL;
int crtDepth = 0;
Symbol* crtFunc = NULL;
Symbol* crtStruct = NULL;

// --- FUNCTION PROTOTYPES ---
Symbol* findSymbol(Symbol** head, const char* name);
Symbol* addSymbol(Symbol** head, const char* name, ClassKind cls);
void initSymbols(Symbol** head);
void cast(Type* dst, Type* src);
void checkAssignment(const char* name, Type exprType);
void checkFunctionCall(const char* fname, Type* argTypes, int nArgs);
void checkReturn(Type exprType);
void printSymbols(Symbol* head, int indent);
void addExtFuncs(void);

// --- ERROR HANDLING ---
void err(const char* fmt, ...) {
    va_list va;
    va_start(va, fmt);
    fprintf(stderr, "error: ");
    vfprintf(stderr, fmt, va);
    fprintf(stderr, "\n");
    va_end(va);
    exit(1);
}

// --- TYPE CREATION ---
Type createType(TypeBase typeBase, int nElements) {
    Type t;
    t.typeBase = typeBase;
    t.s = NULL;
    t.nElements = nElements;
    return t;
}

// --- TYPE CHECKING ---
void cast(Type* dst, Type* src) {
    if (src->nElements > -1) {
        if (dst->nElements > -1) {
            if (src->typeBase != dst->typeBase)
                err("array types are not compatible");
        } else {
            err("cannot assign array to scalar");
        }
    } else if (dst->nElements > -1) {
        err("cannot assign scalar to array");
    }

    if (src->typeBase == TB_STRUCT || dst->typeBase == TB_STRUCT) {
        if (src->typeBase != TB_STRUCT || dst->typeBase != TB_STRUCT || src->s != dst->s)
            err("incompatible struct types");
        return;
    }

    if ((src->typeBase == TB_INT || src->typeBase == TB_DOUBLE || src->typeBase == TB_CHAR) &&
        (dst->typeBase == TB_INT || dst->typeBase == TB_DOUBLE || dst->typeBase == TB_CHAR)) {
        return;
    }

    err("incompatible types");
}

void checkAssignment(const char* name, Type exprType) {
    Symbol* s = findSymbol(&symbols, name);
    if (!s) err("undeclared variable: %s", name);
    cast(&s->type, &exprType);
}

void checkFunctionCall(const char* fname, Type* argTypes, int nArgs) {
    Symbol* f = findSymbol(&symbols, fname);
    if (!f || f->cls != CLS_FUNC) err("'%s' is not a function", fname);

    Symbol* param = f->args;
    for (int i = 0; i < nArgs; i++) {
        if (!param) err("too many arguments in call to %s", fname);
        cast(&param->type, &argTypes[i]);
        param = param->next;
    }
    if (param) err("too few arguments in call to %s", fname);
}

void checkReturn(Type exprType) {
    if (!crtFunc) err("return not inside a function");
    cast(&crtFunc->type, &exprType);
}

// --- SYMBOL TABLE ---
Symbol* findSymbol(Symbol** head, const char* name) {
    for (Symbol* s = *head; s; s = s->next) {
        if (strcmp(s->name, name) == 0) return s;
    }
    return NULL;
}

Symbol* addSymbol(Symbol** head, const char* name, ClassKind cls) {
    Symbol* s = (Symbol*)malloc(sizeof(Symbol));
    if (!s) err("Out of memory");
    strncpy(s->name, name, MAX_NAME);
    s->cls = cls;
    s->depth = crtDepth;
    s->mem = MEM_GLOBAL; // default (important!)
    s->type = createType(TB_VOID, -1); // default void type
    s->next = *head;
    s->args = NULL;
    s->members = NULL;
    *head = s;
    return s;
}

void deleteSymbolsAfter(Symbol** head, Symbol* start) {
    while (*head && *head != start) {
        Symbol* tmp = *head;
        *head = (*head)->next;
        free(tmp);
    }
}

void initSymbols(Symbol** head) {
    *head = NULL;
}

void printSymbols(Symbol* head, int indent) {
    for (Symbol* s = head; s; s = s->next) {
        for (int i = 0; i < indent; i++) printf("  ");
        printf("Name: %s, Class: %d, TypeBase: %d, nElements: %d, Depth: %d\n",
               s->name, s->cls, s->type.typeBase, s->type.nElements, s->depth);
        if (s->cls == CLS_VAR)
            printf("%*sMem: %d\n", indent + 2, "", s->mem);

        if (s->args) {
            for (int i = 0; i < indent + 1; i++) printf("  ");
            printf("Arguments:\n");
            printSymbols(s->args, indent + 2);
        }
        if (s->members) {
            for (int i = 0; i < indent + 1; i++) printf("  ");
            printf("Members:\n");
            printSymbols(s->members, indent + 2);
        }
    }
}


// --- SEMANTIC OPERATIONS ---
void addVar(const char* name, Type t) {
    Symbol* s;
    if (crtStruct) {
        if (findSymbol(&crtStruct->members, name)) err("symbol redefinition in struct: %s", name);
        s = addSymbol(&crtStruct->members, name, CLS_VAR);
    } else if (crtFunc) {
        if ((s = findSymbol(&symbols, name)) && s->depth == crtDepth) err("symbol redefinition: %s", name);
        s = addSymbol(&symbols, name, CLS_VAR);
        s->mem = MEM_LOCAL;
    } else {
        if (findSymbol(&symbols, name)) err("symbol redefinition: %s", name);
        s = addSymbol(&symbols, name, CLS_VAR);
        s->mem = MEM_GLOBAL;
    }
    s->type = t;
}

void beginFunction(const char* name, Type returnType) {
    if (findSymbol(&symbols, name)) err("function redefinition: %s", name);
    crtFunc = addSymbol(&symbols, name, CLS_FUNC);
    initSymbols(&crtFunc->args);
    crtFunc->type = returnType;
    crtDepth++;
}

void endFunction() {
    deleteSymbolsAfter(&symbols, crtFunc);
    crtFunc = NULL;
    crtDepth--;
}

void addFunctionArg(const char* name, Type t) {
    Symbol* s = addSymbol(&symbols, name, CLS_VAR);
    s->mem = MEM_ARG;
    s->type = t;
    Symbol* arg = addSymbol(&crtFunc->args, name, CLS_VAR);
    arg->mem = MEM_ARG;
    arg->type = t;
}

void beginStruct(const char* name) {
    if (findSymbol(&symbols, name)) err("struct redefinition: %s", name);
    crtStruct = addSymbol(&symbols, name, CLS_STRUCT);
    initSymbols(&crtStruct->members);
}

void endStruct() {
    crtStruct = NULL;
}

void enterBlock() {
    crtDepth++;
}

void exitBlock(Symbol* start) {
    deleteSymbolsAfter(&symbols, start);
    crtDepth--;
}

Symbol* addExtFunc(const char* name, Type type) {
    Symbol* s = addSymbol(&symbols, name, CLS_FUNC);
    s->type = type;
    initSymbols(&s->args);
    return s;
}

Symbol* addFuncArg(Symbol* func, const char* name, Type type) {
    Symbol* a = addSymbol(&func->args, name, CLS_VAR);
    a->type = type;
    return a;
}

void addExtFuncs() {
    Symbol* s;

    s = addExtFunc("put_s", createType(TB_VOID, -1));
    addFuncArg(s, "s", createType(TB_CHAR, 0));

    s = addExtFunc("get_s", createType(TB_VOID, -1));
    addFuncArg(s, "s", createType(TB_CHAR, 0));

    s = addExtFunc("put_i", createType(TB_VOID, -1));
    addFuncArg(s, "i", createType(TB_INT, -1));

    s = addExtFunc("get_i", createType(TB_INT, -1));

    s = addExtFunc("put_d", createType(TB_VOID, -1));
    addFuncArg(s, "d", createType(TB_DOUBLE, -1));

    s = addExtFunc("get_d", createType(TB_DOUBLE, -1));

    s = addExtFunc("put_c", createType(TB_VOID, -1));
    addFuncArg(s, "c", createType(TB_CHAR, -1));

    s = addExtFunc("get_c", createType(TB_CHAR, -1));

    s = addExtFunc("seconds", createType(TB_DOUBLE, -1));
}

// --- MAIN ---
int semantic_main() {
    addExtFuncs();

    Type intType = createType(TB_INT, -1);
    addVar("globalVar", intType);

    beginStruct("Point");
    addVar("x", intType);
    addVar("y", intType);
    endStruct();

    Type voidType = createType(TB_VOID, -1);
    beginFunction("myFunc", voidType);
    Type charType = createType(TB_CHAR, -1);
    addFunctionArg("arg1", charType);

    Symbol* blockStart = symbols;
    enterBlock();
    addVar("local1", intType);
    exitBlock(blockStart);

    endFunction();

    printf("Semantic rules executed successfully.\n");
    printf("Symbol table:\n");
    printSymbols(symbols, 0);

    return 0;
}
