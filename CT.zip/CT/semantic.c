#include "lexical_analyzer.h"
#include <stdio.h>
#include <string.h>

// Extend symbol table entry
typedef enum {
    SYM_VARIABLE,
    SYM_FUNCTION
} SymbolKind;

typedef struct {
    char name[MaxTokenLen];
    TokenType type;
    SymbolKind kind;
} Symbol;

#define MAX_SYMBOLS 1000
static Symbol symbol_table[MAX_SYMBOLS];
static int symbol_count = 0;

// Helper: check if symbol exists
static int symbol_exists(const char *name) {
    for (int i = 0; i < symbol_count; i++) {
        if (strcmp(symbol_table[i].name, name) == 0) {
            return i;
        }
    }
    return -1;
}

// Add symbol to table, return 1 on success, 0 if duplicate
static int add_symbol(const char *name, TokenType type, SymbolKind kind) {
    int idx = symbol_exists(name);
    if (idx != -1) 
    {
        // Silently ignore redeclaration for known built-ins
        if (strcmp(name, "put_s") == 0 || strcmp(name, "put_c") == 0 || strcmp(name, "main") == 0) {
            return 0;
        }

        printf("Semantic error: '%s' redeclared\n", name);
        return 0;
    }

    if (symbol_count < MAX_SYMBOLS) {
        strcpy(symbol_table[symbol_count].name, name);
        symbol_table[symbol_count].type = type;
        symbol_table[symbol_count].kind = kind;
        symbol_count++;
        return 1;
    } else {
        printf("Symbol table overflow\n");
        return 0;
    }
}

// Check if symbol declared, return 1 if yes, 0 if no
static int check_symbol_declared(const char *name) {
    return symbol_exists(name) != -1;
}

int semantic_main() {
    int semantic_errors = 0;
    symbol_count = 0;

    // Add built-in functions to symbol table (to avoid errors)
    add_symbol("put_s", T_VOID, SYM_FUNCTION);
    add_symbol("put_c", T_VOID, SYM_FUNCTION);
    add_symbol("main", T_VOID, SYM_FUNCTION);  // Add main upfront!

    for (int i = 0; i < token_list_index; i++) {
        Token token = token_list[i];

        // Detect function declarations: look for pattern "void IDENTIFIER ( ... )"
        if (token.type == T_VOID) {
            if (i + 1 < token_list_index && token_list[i + 1].type == T_IDENTIFIER) {
                char func_name[MaxTokenLen];
                strcpy(func_name, token_list[i + 1].value.string_value);

                if (!add_symbol(func_name, T_VOID, SYM_FUNCTION)) {
                    semantic_errors = 1;
                }
                i += 2;  // Skip '(' token etc.
                continue;
            }
        }

        // Detect variable declarations (int, char, double)
        if (token.type == T_INT || token.type == T_CHAR || token.type == T_DOUBLE) {
            if (i + 1 < token_list_index && token_list[i + 1].type == T_IDENTIFIER) {
                char var_name[MaxTokenLen];
                strcpy(var_name, token_list[i + 1].value.string_value);

                if (!add_symbol(var_name, token.type, SYM_VARIABLE)) {
                    semantic_errors = 1;
                }
                continue;
            }
        }

        // Check usage of identifiers
        if (token.type == T_IDENTIFIER) {
            char name[MaxTokenLen];
            strcpy(name, token.value.string_value);

            if (!check_symbol_declared(name)) {
                printf("Semantic error: variable or function '%s' used without declaration\n", name);
                semantic_errors = 1;
            }
        }
    }

    // Print symbol table
    printf("\nSymbol Table:\n");
    printf("----------------------------\n");
    printf("%-20s %-10s %-10s\n", "Name", "Type", "Kind");
    for (int i = 0; i < symbol_count; i++) {
        printf("%-20s %-10s %-10s\n",
               symbol_table[i].name,
               token_type_to_string(symbol_table[i].type),
               (symbol_table[i].kind == SYM_FUNCTION) ? "Function" : "Variable");
    }
    printf("----------------------------\n");

    if (!semantic_errors) {
        printf("----------------------SEMANTIC COMPLETE------------------------\n");
        printf("Semantic analysis completed successfully!\n\n");
    } else {
        printf("Semantic analysis completed with errors.\n\n");
    }

    return semantic_errors;
}
