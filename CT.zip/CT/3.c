void main()
{
	int		x;
	put_s("x=");
	x=get_i();
	if(x<0)put_s("negativ");
		else put_s("pozitiv");
}
