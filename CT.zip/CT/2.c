void main()
{
	int		x;
	put_s("x=");
	x=get_i();
	put_i(x);
}
